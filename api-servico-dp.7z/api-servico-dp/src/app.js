const express = require('express')
const app = express()
app.use(express.json())
const mongoose = require('mongoose') 

mongoose.connect('mongodb://fiap:123456@localhost:27017/admin')

app.use(express.urlencoded({
    extended: true
}))

require('./models/produto')

const produtoRouter = require('./routers/folha-router')
const index = require('./routers/index')

app.use('/', index)
app.use('/produto', produtoRouter)
module.exports = app;